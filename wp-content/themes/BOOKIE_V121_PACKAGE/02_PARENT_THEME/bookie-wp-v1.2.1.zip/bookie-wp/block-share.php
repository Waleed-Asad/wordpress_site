<div class="sharrre">
	<div class="share-box">
		<ul class="text-center">
			<li>
				<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
			</li>
			<li>
				<a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
			</li>
			<li>
				<a href="#" class="googleplus"><i class="fa fa-google-plus"></i></a>
			</li>
			<li>
				<a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
			</li>
			<li>
				<a href="#" class="pinterest"><i class="fa fa-pinterest"></i></a>
			</li>
		</ul>
	</div>
</div>
